/*
 * Daniel Vazquez
 * Aritificial Intelligence for Robotics
 * SS 2016
 * Assignment 6
 *
 * main.cpp
 * */

#include "environment.hpp"

int main(int argc, char const *argv[]) {
	Environment env;
	env.run();
	return 0;
}
